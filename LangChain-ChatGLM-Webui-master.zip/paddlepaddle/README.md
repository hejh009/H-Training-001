# LangChain-ChatGLM-Paddle

LangChain-ChatGLM的Paddle版本依赖 `PaddlePaddle` 和 `PaddleNLP` 的develop版本

在AIStudio上可以一键运行:[链接](https://aistudio.baidu.com/aistudio/projectdetail/6195067)
